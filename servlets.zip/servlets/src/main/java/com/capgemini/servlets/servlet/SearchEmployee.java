package com.capgemini.servlets.servlet;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.servlets.dto.EmployeeBeen;
import com.capgemini.servlets.service.EmployeeService;
import com.capgemini.servlets.service.EmployeeServiceImpl;

@WebServlet("./searchemp")
public class SearchEmployee extends HttpServlet {
	private EmployeeService service = new EmployeeServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		String empIdVal = req.getParameter("empId");
		int empId  = Integer.parseInt(empIdVal);
		
		
	EmployeeBeen employeebean =service.getEmployeeByid(empId);
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("<html>");
		out.print("<body>");
		if(employeebean != null) {
			out.print("<table border='1'>                          ");
			out.print("<thead>                                     ");
			out.print("<tr style=\"color :white;background:navy;\">");
			out.print("<th>Employee Id</th>                         ");
			out.print("<th>Employee Name</th>                        ");
			out.print("<th>Age</th>                                  ");
			out.print("<th>Salary</th>                               ");
			out.print("<th>Designation</th>                           ");
			out.print("<th>password</th>                              ");
			out.print("<tr>                                           ");
			out.print("<thead>                                        ");
			out.print("<tbody>                                        ");
			out.print("        <tr>                                   ");
			out.print("            <td>employeeInfoBean.getEmpId()</td>");
			out.print("            <td>employeeInfoBean.getEmpName()</td>");
			out.print("            <td>employeeInfoBean.getAge()</td>");
			out.print("            <td>employeeInfoBean.getSalary()</td>");
			out.print("            <td>employeeInfoBean.getDesignation()</td>");
			out.print("            <td>employeeInfoBean.getPassword()</td>");
			out.print("<tr>"                                               );
			out.print("<tbody>                                            ");
			out.print("<table>                                             ");
			
			}else {
			out.print("<h2 style='color :red'>Employee Id "+empId+"not found");
		    }
		out.print("</html>");
		out.print("</body>");	
		RequestDispatcher dispatcher =req.getRequestDispatcher("./homepage.html");
		dispatcher.include(req, resp);
		
	}


}
