package com.capgemini.servlets.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.servlets.dto.EmployeeBeen;

public class EmployeeDAOImpl implements EmployeeDAO {

	public EmployeeBeen getEmployeeByid(int empId) {
		EmployeeBeen employeeInfoBean = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernatedb", "root","root");
			pstmt = connection.prepareStatement("select * from employeedata where empId=?");
			pstmt.setInt(1, empId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				employeeInfoBean = new EmployeeBeen();
				employeeInfoBean.setEmpId(rs.getInt("empId"));
				employeeInfoBean.setAge(rs.getInt("age"));
				employeeInfoBean.setEmpName(rs.getString("name"));
				employeeInfoBean.setDesignation(rs.getString("designation"));
				employeeInfoBean.setPassword(rs.getString("password"));
				employeeInfoBean.setSalary(rs.getDouble("salary"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		return employeeInfoBean;
	}

	public boolean addEmployee(EmployeeBeen bean) {

		String query1 = "insert into employeedata values(?,?,?,?,?,?)";

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernatedb","root","root");

			PreparedStatement preparedStatement3 = connection.prepareStatement(query1);

			preparedStatement3.setInt(1, bean.getEmpId());
			preparedStatement3.setString(2, bean.getEmpName());
			preparedStatement3.setInt(3, bean.getAge());
			preparedStatement3.setDouble(4, bean.getSalary());
			preparedStatement3.setString(5, bean.getDesignation());
			preparedStatement3.setString(6, bean.getPassword());

			int result = preparedStatement3.executeUpdate();

			if (result != 0) {
				System.out.println("values are inserted succefully");

			}

			connection.close();

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return false;

	}

	public boolean updateEmployee(EmployeeBeen been) {
		EmployeeBeen emppbean = null;
		boolean isUpdated = false;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernatedb", "root",
					"root");
			PreparedStatement pstmt = connection
					.prepareStatement("update employeedata set empname=? where empid=? ");
			pstmt.setString(1, been.getEmpName());
			pstmt.setInt(2, been.getEmpId());

			int result = pstmt.executeUpdate();
			if (result > 0) {
				System.out.println("values are updated succefully");
				isUpdated = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return isUpdated;
	}

	public boolean deleteEmployee(int Id) {
		EmployeeBeen empbean = null;
		boolean isDeleted = false;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernatedb", "root",
					"root");
			PreparedStatement pstmt1 = connection.prepareStatement("delete from  employeedata  where EmpId=?");

			pstmt1.setInt(1, empbean.getEmpId());

			int result = pstmt1.executeUpdate();
			if (result > 0) {
				System.out.println("values deleted succefully");
				isDeleted = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return isDeleted;
	}

	public List<EmployeeBeen> getAllEmployees() {
		List<EmployeeBeen> listInfo = new ArrayList<EmployeeBeen>();

		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernatedb", "root",
					"root");
			PreparedStatement pstmt1 = connection.prepareStatement("select * from employeedata");
			rs = pstmt1.executeQuery();

			while (rs.next()) {
				EmployeeBeen been2 = new EmployeeBeen();

				been2.setEmpName(rs.getString("name"));
				been2.setAge(rs.getInt("Age"));
				been2.setPassword(rs.getString("password"));
				been2.setDesignation(rs.getString("designation"));
				been2.setSalary(rs.getDouble("salary"));
				been2.setEmpId(rs.getInt("empId"));

				listInfo.add(been2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		return listInfo;

	}

	public EmployeeBeen authenticate(int empId, String password) {
		EmployeeBeen employeeInfoBean = getEmployeeByid(empId);
		if (!(employeeInfoBean != null && employeeInfoBean.getPassword().equals(password))) {
			employeeInfoBean = null;
		}
		return null;
	}

}
