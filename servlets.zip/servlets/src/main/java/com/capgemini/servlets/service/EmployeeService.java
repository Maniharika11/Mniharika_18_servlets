package com.capgemini.servlets.service;

import java.util.List;

import com.capgemini.servlets.dto.EmployeeBeen;

public interface EmployeeService {
	public EmployeeBeen getEmployeeByid(int Id);
	public boolean addEmployee(EmployeeBeen bean);
	public boolean updateEmployee(EmployeeBeen bean);
	public boolean deleteEmployee(int Id);
	public List<EmployeeBeen> getAllEmployees();
	public EmployeeBeen authenticate(int empId,String password);

}
