package com.capgemini.servlets.service;

import java.util.List;

import com.capgemini.servlets.dao.EmployeeDAO;
import com.capgemini.servlets.dao.EmployeeDAOImpl;
import com.capgemini.servlets.dto.EmployeeBeen;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO empdao=new EmployeeDAOImpl();

	public EmployeeBeen getEmployeeByid(int Id) {
		// TODO Auto-generated method stub
		return empdao.getEmployeeByid(Id);
	}

	public boolean addEmployee(EmployeeBeen bean) {
		// TODO Auto-generated method stub
		return empdao.addEmployee(bean);
	}

	public boolean updateEmployee(EmployeeBeen bean) {
		// TODO Auto-generated method stub
		return empdao.updateEmployee(bean);
	}

	public boolean deleteEmployee(int Id) {
		// TODO Auto-generated method stub
		return empdao.deleteEmployee(Id);
	}

	public List<EmployeeBeen> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public EmployeeBeen authenticate(int empId, String password) {
		// TODO Auto-generated method stub
		return empdao.authenticate(empId, password);
	}

}
